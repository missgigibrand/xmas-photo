/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { HolidayApp } from './services/HolidayApp';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX } from 'lucide-react';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const appRef = useRef<HolidayApp | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUiVisible, setIsUiVisible] = useState(true);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  useEffect(() => {
    if (containerRef.current && videoRef.current && !appRef.current) {
      appRef.current = new HolidayApp(
        containerRef.current,
        videoRef.current,
        () => setIsLoading(false)
      );
      appRef.current.animate();
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'h') {
        setIsUiVisible(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      appRef.current?.destroy();
    };
  }, []);

  const toggleMusic = () => {
    const newState = !isMusicPlaying;
    setIsMusicPlaying(newState);
    appRef.current?.toggleMusic(newState);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && appRef.current) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result;
        if (typeof result === 'string') {
          new THREE.TextureLoader().load(result, (texture) => {
            texture.colorSpace = THREE.SRGBColorSpace;
            appRef.current?.addPhoto(texture);
            appRef.current?.playJingle();
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-[#fceea7]">
      {/* Three.js Canvas Container */}
      <div ref={containerRef} className="absolute inset-0 z-0" />

      {/* Loading Screen */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black"
          >
            <div className="spinner mb-5" />
            <div className="tracking-[4px] text-xs uppercase">Loading Holiday Magic</div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* UI Overlay */}
      <motion.div
        animate={{ opacity: isUiVisible ? 1 : 0 }}
        className="fixed inset-0 z-10 pointer-events-none flex flex-col items-center pt-10"
      >
        <h1 className="cinzel text-5xl md:text-7xl m-0 bg-gradient-to-b from-white to-[#d4af37] bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(212,175,55,0.6)]">
          Merry Christmas
        </h1>

        <div className="mt-8 pointer-events-auto flex flex-col items-center gap-6">
          <div className="flex items-center gap-4">
            <label className="inline-block px-8 py-3 bg-white/5 border border-[#d4af37] text-[#d4af37] backdrop-blur-md cursor-pointer text-sm tracking-[2px] transition-all hover:bg-[#d4af37] hover:text-black">
              ADD MEMORIES
              <input
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleFileUpload}
              />
            </label>
            
            <button
              onClick={toggleMusic}
              className="p-3 bg-white/5 border border-[#d4af37] text-[#d4af37] backdrop-blur-md cursor-pointer transition-all hover:bg-[#d4af37] hover:text-black"
              title={isMusicPlaying ? "Mute Music" : "Play Music"}
            >
              {isMusicPlaying ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </button>
          </div>

          <div className="text-[10px] md:text-xs opacity-60 tracking-widest uppercase">
            Press 'H' to Hide Controls
          </div>
        </div>
      </motion.div>

      {/* Hidden Webcam for Hand Tracking */}
      <div className="fixed bottom-5 right-5 opacity-0 pointer-events-none">
        <video ref={videoRef} autoPlay playsInline className="w-40 h-30" />
      </div>
    </div>
  );
}
