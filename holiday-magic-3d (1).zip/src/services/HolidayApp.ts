/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { HandLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';

const COLORS = {
  gold: 0xd4af37,
  darkGreen: 0x062e03,
  holidayRed: 0xb22222,
  iceBlue: 0xadd8e6
};

export type SceneMode = 'TREE' | 'SCATTER' | 'FOCUS';

class HolidayElement {
  type: string;
  mesh: THREE.Mesh;
  originalScale: number;
  velocity: THREE.Vector3;
  rotSpeed: THREE.Euler;
  targetPos: THREE.Vector3;
  targetRot: THREE.Euler;
  targetScale: THREE.Vector3;
  scatterPos?: THREE.Vector3;

  constructor(type: string, scene: THREE.Group | THREE.Scene) {
    this.type = type;
    this.mesh = this.createMesh(type);
    this.originalScale = this.mesh.scale.x;
    this.velocity = new THREE.Vector3(
      (Math.random() - 0.5) * 0.02,
      (Math.random() - 0.5) * 0.02,
      (Math.random() - 0.5) * 0.02
    );
    this.rotSpeed = new THREE.Euler(
      Math.random() * 0.02,
      Math.random() * 0.02,
      Math.random() * 0.02
    );
    this.targetPos = new THREE.Vector3();
    this.targetRot = new THREE.Euler();
    this.targetScale = new THREE.Vector3(1, 1, 1);

    scene.add(this.mesh);
  }

  createMesh(type: string) {
    let geo: THREE.BufferGeometry, mat: THREE.Material | THREE.Material[];
    switch (type) {
      case 'BOX':
        geo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
        mat = new THREE.MeshStandardMaterial({ color: Math.random() > 0.5 ? COLORS.gold : COLORS.darkGreen, metalness: 0.8, roughness: 0.2 });
        break;
      case 'SPHERE':
        geo = new THREE.SphereGeometry(0.3, 24, 24);
        mat = new THREE.MeshPhysicalMaterial({
          color: Math.random() > 0.5 ? COLORS.gold : COLORS.holidayRed,
          metalness: 0.9,
          roughness: 0.1,
          clearcoat: 1.0
        });
        break;
      case 'CANDY':
        geo = this.createCandyCaneGeo();
        mat = new THREE.MeshStandardMaterial({ map: this.createCandyTexture() });
        break;
      case 'PHOTO':
      default:
        geo = new THREE.BoxGeometry(4, 3, 0.2);
        const canvas = document.createElement('canvas');
        canvas.width = 512; canvas.height = 384;
        const ctx = canvas.getContext('2d')!;
        ctx.fillStyle = '#1a1a1a'; ctx.fillRect(0, 0, 512, 384);
        ctx.strokeStyle = '#d4af37'; ctx.lineWidth = 40; ctx.strokeRect(0, 0, 512, 384);
        ctx.fillStyle = '#d4af37'; ctx.font = 'bold 40px serif'; ctx.textAlign = 'center';
        ctx.fillText('JOYEUX NOEL', 256, 200);
        const tex = new THREE.CanvasTexture(canvas);
        mat = [
          new THREE.MeshStandardMaterial({ color: 0x333333 }), // side
          new THREE.MeshStandardMaterial({ color: 0x333333 }), // side
          new THREE.MeshStandardMaterial({ color: 0x333333 }), // side
          new THREE.MeshStandardMaterial({ color: 0x333333 }), // side
          new THREE.MeshStandardMaterial({ map: tex }),       // front
          new THREE.MeshStandardMaterial({ color: 0x111111 })  // back
        ];
        break;
    }
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(Math.random() * 100 - 50, Math.random() * 100 - 50, Math.random() * 100 - 50);
    return mesh;
  }

  createCandyCaneGeo() {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 1.5, 0),
      new THREE.Vector3(0.5, 2, 0),
      new THREE.Vector3(1, 1.8, 0)
    ]);
    return new THREE.TubeGeometry(curve, 20, 0.08, 8, false);
  }

  createCandyTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = '#b22222';
    ctx.lineWidth = 20;
    ctx.beginPath();
    ctx.moveTo(-50, 0); ctx.lineTo(128, 178);
    ctx.moveTo(0, -50); ctx.lineTo(178, 128);
    ctx.stroke();
    return new THREE.CanvasTexture(canvas);
  }

  update(mode: SceneMode) {
    if (mode === 'SCATTER') {
      this.mesh.rotation.x += this.rotSpeed.x;
      this.mesh.rotation.y += this.rotSpeed.y;
    }

    const lerpFactor = 0.05;
    this.mesh.position.lerp(this.targetPos, lerpFactor);
    this.mesh.quaternion.slerp(new THREE.Quaternion().setFromEuler(this.targetRot), lerpFactor);
    this.mesh.scale.lerp(this.targetScale, lerpFactor);
  }
}

export class HolidayApp {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  composer: EffectComposer;
  bloomPass: UnrealBloomPass;
  mainGroup: THREE.Group;
  elements: HolidayElement[] = [];
  dust: THREE.Points | any;
  handLandmarker: any = null;
  mode: SceneMode = 'TREE';
  targetRotation = { x: 0, y: 0 };
  focusedObject: HolidayElement | null = null;
  onLoaded: () => void;
  bgMusic: HTMLAudioElement | null = null;
  jingleSfx: HTMLAudioElement | null = null;

  constructor(container: HTMLElement, video: HTMLVideoElement, onLoaded: () => void) {
    this.onLoaded = onLoaded;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.camera.position.set(0, 2, 50);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ReinhardToneMapping;
    this.renderer.toneMappingExposure = 2.2;
    container.appendChild(this.renderer.domElement);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    this.mainGroup = new THREE.Group();
    this.scene.add(this.mainGroup);

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.45, 0.4, 0.7
    );
    this.composer.addPass(this.bloomPass);

    this.initLights();
    this.createParticles();
    this.initMediaPipe(video);
    this.initAudio();

    window.addEventListener('resize', this.onResize);
  }

  initAudio() {
    this.bgMusic = new Audio('https://assets.mixkit.co/music/preview/mixkit-christmas-magic-30.mp3');
    this.bgMusic.loop = true;
    this.bgMusic.volume = 0.4;

    this.jingleSfx = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-jingle-bell-calm-1433.mp3');
    this.jingleSfx.volume = 0.3;
  }

  toggleMusic(play: boolean) {
    if (play) {
      this.bgMusic?.play().catch(e => console.log("Audio play blocked", e));
    } else {
      this.bgMusic?.pause();
    }
  }

  playJingle() {
    if (this.jingleSfx) {
      this.jingleSfx.currentTime = 0;
      this.jingleSfx.play().catch(e => console.log("SFX play blocked", e));
    }
  }

  onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.composer.setSize(window.innerWidth, window.innerHeight);
  }

  initLights() {
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    this.scene.add(ambient);

    const point = new THREE.PointLight(0xffaa00, 2);
    point.position.set(0, 5, 0);
    this.scene.add(point);

    const spot1 = new THREE.SpotLight(0xd4af37, 1200);
    spot1.position.set(30, 40, 40);
    spot1.angle = 0.5;
    this.scene.add(spot1);

    const spot2 = new THREE.SpotLight(0x4444ff, 600);
    spot2.position.set(-30, 20, -30);
    spot2.angle = 0.5;
    this.scene.add(spot2);
  }

  createParticles() {
    this.elements = [];
    for (let i = 0; i < 1500; i++) {
      const types = ['BOX', 'SPHERE', 'CANDY'];
      const el = new HolidayElement(types[i % 3], this.mainGroup);
      this.elements.push(el);
    }

    const photo = new HolidayElement('PHOTO', this.mainGroup);
    this.elements.push(photo);

    const dustGeo = new THREE.BufferGeometry();
    const dustPos = new Float32Array(2500 * 3);
    for (let i = 0; i < 2500 * 3; i++) dustPos[i] = (Math.random() - 0.5) * 100;
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    const dustMat = new THREE.PointsMaterial({ color: 0xfceea7, size: 0.05, transparent: true, opacity: 0.6 });
    this.dust = new THREE.Points(dustGeo, dustMat);
    this.scene.add(this.dust);
  }

  async initMediaPipe(video: HTMLVideoElement) {
    const vision = await FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm");
    this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
        delegate: "GPU"
      },
      runningMode: "VIDEO",
      numHands: 1
    });

    if (navigator.mediaDevices.getUserMedia) {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
      video.srcObject = stream;
      video.addEventListener('loadeddata', () => {
        this.onLoaded();
        this.detectHands(video);
      });
    }
  }

  detectHands(video: HTMLVideoElement) {
    if (!this.handLandmarker) return;
    const startTimeMs = performance.now();
    const results = this.handLandmarker.detectForVideo(video, startTimeMs);

    if (results.landmarks && results.landmarks.length > 0) {
      const hand = results.landmarks[0];
      this.processGestures(hand);
      this.targetRotation.y = (hand[9].x - 0.5) * 2.0;
      this.targetRotation.x = (hand[9].y - 0.5) * 1.0;
    }
    requestAnimationFrame(() => this.detectHands(video));
  }

  processGestures(hand: any[]) {
    const getDist = (p1: any, p2: any) => Math.hypot(p1.x - p2.x, p1.y - p2.y, p1.z - p2.z);

    const thumbTip = hand[4];
    const indexTip = hand[8];
    const wrist = hand[0];

    const pinchDist = getDist(thumbTip, indexTip);
    const avgFingerDist = (getDist(hand[8], wrist) + getDist(hand[12], wrist) + getDist(hand[16], wrist) + getDist(hand[20], wrist)) / 4;

    if (pinchDist < 0.05) {
      if (this.mode !== 'FOCUS') this.setMode('FOCUS');
    } else if (avgFingerDist < 0.25) {
      this.setMode('TREE');
    } else if (avgFingerDist > 0.4) {
      this.setMode('SCATTER');
    }
  }

  setMode(mode: SceneMode) {
    if (this.mode !== mode) {
      this.playJingle();
    }
    this.mode = mode;
    if (mode === 'FOCUS') {
      const photos = this.elements.filter(e => e.type === 'PHOTO');
      this.focusedObject = photos[Math.floor(Math.random() * photos.length)];
    }
  }

  addPhoto(texture: THREE.Texture) {
    const el = new HolidayElement('PHOTO', this.mainGroup);
    if (Array.isArray(el.mesh.material)) {
      (el.mesh.material[4] as THREE.MeshStandardMaterial).map = texture;
    }
    this.elements.push(el);
    this.setMode('FOCUS');
    this.focusedObject = el;
  }

  updateLayout() {
    this.elements.forEach((el, i) => {
      if (this.mode === 'TREE') {
        const t = i / this.elements.length;
        const height = 30;
        const radius = (1 - t) * 12;
        const angle = t * Math.PI * 60;
        el.targetPos.set(
          Math.cos(angle) * radius,
          t * height - height / 2,
          Math.sin(angle) * radius
        );
        el.targetRot.set(0, -angle, 0);
        el.targetScale.set(1, 1, 1);
      }
      else if (this.mode === 'SCATTER') {
        if (!el.scatterPos) {
          const r = 8 + Math.random() * 12;
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.random() * Math.PI;
          el.scatterPos = new THREE.Vector3(
            r * Math.sin(phi) * Math.cos(theta),
            r * Math.sin(phi) * Math.sin(theta),
            r * Math.cos(phi)
          );
        }
        el.targetPos.copy(el.scatterPos);
        el.targetScale.set(1, 1, 1);
      }
      else if (this.mode === 'FOCUS') {
        if (el === this.focusedObject) {
          el.targetPos.set(0, 2, 35);
          el.targetRot.set(0, 0, 0);
          el.targetScale.set(4.5, 4.5, 4.5);
        } else {
          const angle = (i / this.elements.length) * Math.PI * 2;
          el.targetPos.set(Math.cos(angle) * 25, Math.sin(angle) * 15, 0);
          el.targetScale.set(0.5, 0.5, 0.5);
        }
      }
      el.update(this.mode);
    });

    this.dust.rotation.y += 0.001;
    this.mainGroup.rotation.y = THREE.MathUtils.lerp(this.mainGroup.rotation.y, this.targetRotation.y, 0.05);
    this.mainGroup.rotation.x = THREE.MathUtils.lerp(this.mainGroup.rotation.x, this.targetRotation.x, 0.05);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.updateLayout();
    this.composer.render();
  }

  destroy() {
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
  }
}
